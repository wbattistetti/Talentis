export interface VisionStep {
  icon: string;
  title: string;
  description: string;
  keywords?: string[];
}